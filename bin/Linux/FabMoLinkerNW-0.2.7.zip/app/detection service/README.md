# FabMo Linker

## Requirement

[Node.js](http://nodejs.org/)

## Usage

This Software is to be used in localhost.
It provide easy ways to detect tools on the networks.
It works on port 8080.  

launch the Linker : 
 * on linux
 ```bash
 node server.js  
 ```
 * on Windows
 click on 'start FabMo Linker'

Documentation of the API [here](http://docs.shopbotlocalapi.apiary.io/)

## Developing

develloped by [jlucidar](github.com/jlucidar)

### Tools

Using [Restify](http://mcavage.me/node-restify/)
Using [Uniq](https://github.com/mikolalysenko/uniq)
